
public class Aluno {
	
	String nome;

}
