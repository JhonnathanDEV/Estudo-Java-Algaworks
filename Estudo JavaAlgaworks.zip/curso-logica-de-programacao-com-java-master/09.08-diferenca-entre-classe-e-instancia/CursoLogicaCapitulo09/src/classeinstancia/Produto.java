package classeinstancia;

public class Produto {
	
	static Integer quantidadeMinimaEstoque = 1;
	
	String nome;
	
	String getNome() {
		return nome;
	}

}
