package classeinstancia;

public class Impressao {
	
	static void informacao(String texto) {
		System.out.println("[INFO] " + texto);
	}
	
	static void erro(String texto) {
		System.out.println("[ERRO] " + texto);
	}

}
