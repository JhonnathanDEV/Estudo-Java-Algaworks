package primeiraclasse;

public class Produto {
	
	String nome;
	
	Double precoUnitario;
	
	Integer quantidade;

}
