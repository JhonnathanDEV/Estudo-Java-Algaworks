/**
 * Essa classe é a resposta para o primeiro exercício.
 */
public class Exercicio01 {
	
	public static void main(String[] args) {
		System.out.println("Imprimindo uma mensagem diferente :)");
	}
}