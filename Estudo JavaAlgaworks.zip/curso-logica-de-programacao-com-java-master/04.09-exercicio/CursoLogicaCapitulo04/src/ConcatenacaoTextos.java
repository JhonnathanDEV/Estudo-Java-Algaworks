
public class ConcatenacaoTextos {

	public static void main(String[] args) {
		String inicio = "Esse é o ";
		String meio = "º exemplo ";
		String fim = "sobre concatenação de textos.";
		Integer numeroExemplo = 2;
		
		
		System.out.println(inicio + numeroExemplo + meio + fim);
		
		//System.out.println("Esse " + meio + "de concatenação de textos.");
	}

}
