
public class OperadoresIncrementoDecremento {

	public static void main(String[] args) {
//		Integer numero = 10;
//		System.out.println("Número antes: " + numero);
//		numero++;		
//		System.out.println("Número depois: " + numero);
		
//		Integer numero = 10;
//		Integer numero02 = ++numero; // Primeiro incrementa e depois passa o valor para a variável "numero02"
//		Integer numero02 = numero++; // Passa o valor para a variável "numero02" e depois incrementa.
//		System.out.println("Número: " + numero + ", " + "Número02: " + numero02);
		
		Integer numero = 10;
		--numero;
		System.out.println("Número: " + numero);
	}

}
