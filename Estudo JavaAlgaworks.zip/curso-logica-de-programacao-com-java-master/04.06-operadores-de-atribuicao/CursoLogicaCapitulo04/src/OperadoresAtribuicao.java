
public class OperadoresAtribuicao {
	
	public static void main(String[] args) {
		Double numero = 7.0;
		
//		numero = numero + 4;
//		System.out.println("numero + 4: " + numero);
		
//		numero += 4;
//		System.out.println("numero += 4: " + numero);
		
//		numero -= 4;
//		System.out.println("numero -= 4: " + numero);
		
//		numero *= 4;
//		System.out.println("numero *= 4: " + numero);
		
//		numero /= 4;
//		System.out.println("numero /= 4: " + numero);
		
		numero %= 4;
		System.out.println("numero %= 4: " + numero);
	}

}
